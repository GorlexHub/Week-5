class PagesController < ApplicationController

		def team
		end

		def contact
		end

		def potins
		end

		def welcome
			@name = params[:name]
		end

		def home
		end

		def post_1
		end

		def post_2
		end

		def post_3
		end
end
