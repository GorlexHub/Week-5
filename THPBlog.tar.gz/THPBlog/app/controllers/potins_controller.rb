class PotinsController < ApplicationController
  def index
  	@potins = Potin.all
  end
end
