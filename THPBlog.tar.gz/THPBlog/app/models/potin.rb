class Potin < ApplicationRecord

end