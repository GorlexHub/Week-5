Rails.application.routes.draw do

	root to: 'potins#index', as: 'home'
	get '/post_1', to: 'pages#post_1', as: 'post_1'
	get '/post_2', to: 'pages#post_2', as: 'post_2'
	get '/post_3', to: 'pages#post_3', as: 'post_3'
	get '/contact', to: 'pages#contact', as: 'contact'
	get '/team', to: 'pages#team', as:'team'
	get '/welcome/:name', to: 'pages#welcome', as: 'welcome'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
