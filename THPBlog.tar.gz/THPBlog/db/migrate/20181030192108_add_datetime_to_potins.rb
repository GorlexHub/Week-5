class AddDatetimeToPotins < ActiveRecord::Migration[5.2]
  def change
    add_column :potins, :Date, :Integer
  end
end
