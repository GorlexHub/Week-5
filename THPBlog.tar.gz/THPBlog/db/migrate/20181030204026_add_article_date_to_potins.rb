class AddArticleDateToPotins < ActiveRecord::Migration[5.2]
  def change
    add_column :potins, :Article_Date, :Integer
  end
end
